print('            Nothing','will work','unless you do',sep='\n')
