number=int(input ('input number: '))
a2=(number//10)%10
a1=number//100
a3=number%10
sum=a1+a2+a3
print(a1)
print(a2)
print(a3)
print(sum)