print('Nothing')
print('tuiouo')
print('aKJDAS')